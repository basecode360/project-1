// src/pages/Login.jsx
import React from "react";
import { Button, Typography, Container, Box } from "@mui/material";

const Login = ({ handleLogin }) => {
  return (
    <Container maxWidth="sm" sx={{ mt: 8, textAlign: 'center' }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Seller Bay Republic
      </Typography>
      <Typography variant="body1" gutterBottom>
        Click the button below to log in
      </Typography>
      <Box mt={4}>
        <Button 
          variant="contained" 
          color="primary" 
          size="large"
          onClick={handleLogin}
        >
          Login
        </Button>
      </Box>
    </Container>
  );
};

export default Login;