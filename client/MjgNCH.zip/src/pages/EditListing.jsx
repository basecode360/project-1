import React from "react";
import Form from "../componentsForEditListing/Form";
import ListingsTable from "../componentsForEditListing/ListingsTable";

export default function EditListing() {
  return (
    <>
      <Form />
      <ListingsTable />
    </>
  );
}
